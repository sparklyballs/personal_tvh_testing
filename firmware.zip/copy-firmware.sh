#!/bin/bash

cp ./dvb-fe-ds300x.fw /lib/firmware/
cp ./dvb-fe-ds3103.fw /lib/firmware/
cp ./dvb-fe-rs6000.fw /lib/firmware/

cp ./dvb-demod-m88ds3103.fw /lib/firmware/
cp ./dvb-demod-m88rs6000.fw /lib/firmware/

cp ./dvb-demod-si2168-a20-01.fw /lib/firmware/
cp ./dvb-demod-si2168-a30-01.fw /lib/firmware/
cp ./dvb-demod-si2168-b40-01.fw /lib/firmware/
cp ./dvb-tuner-si2158-a20-01.fw /lib/firmware/

echo "Copy Firmware for DVBSky card/box."
